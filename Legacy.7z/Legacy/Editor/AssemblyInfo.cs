﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[assembly: UnityEditor.UIElements.UxmlNamespacePrefix("RoR2EditorKit.VisualElements", "r2ek")]