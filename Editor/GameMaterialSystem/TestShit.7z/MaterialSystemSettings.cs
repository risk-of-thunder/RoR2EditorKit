using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace RoR2.Editor
{
    [FilePath("ProjectSettings/RoR2EditorKit/MaterialSystemSettings.asset", FilePathAttribute.Location.ProjectFolder)]
    public sealed class MaterialSystemSettings : ScriptableSingleton<MaterialSystemSettings>
    {
        private Dictionary<string, Shader> _addressableShaderToStubbedShader;

        [SerializeField]
        private List<AddressableShaderToStubbedPair> _serializedDictionary = new List<AddressableShaderToStubbedPair>();

        public void Add(string addressableShaderName, Shader stubbedShader)
        {
            for (int i = 0; i < _serializedDictionary.Count; i++)
            {
                var entry = _serializedDictionary[i];
                if(entry.addressableShaderName == addressableShaderName)
                {
                    entry.stubbedShader.shader = stubbedShader;
                    ReloadDictionary();
                    return;
                }
            }

            _serializedDictionary.Add(new AddressableShaderToStubbedPair
            {
                addressableShaderName = addressableShaderName,
                stubbedShader = new SerializableShaderWrapper(stubbedShader),
            });
            ReloadDictionary();
        }

        public bool AlreadyExists(string addressableShaderName)
        {
            if (_addressableShaderToStubbedShader == null)
                ReloadDictionary();

            return _addressableShaderToStubbedShader.ContainsKey(addressableShaderName);
        } 

        public Shader GetStubbed(string addressableShaderName)
        {
            if (_addressableShaderToStubbedShader == null)
                ReloadDictionary();

            if (_addressableShaderToStubbedShader.TryGetValue(addressableShaderName, out var stubbedShader))
                return stubbedShader;

            Debug.LogWarning($"Could not find stubbed shader for addressable shader of name {addressableShaderName}. Assigning the Standard shader.");
            return Shader.Find("Standard");
        }

        public void SaveSettings()
        {
            Save(true);
        }

        private void ReloadDictionary()
        {
            if (_addressableShaderToStubbedShader == null)
                _addressableShaderToStubbedShader = new Dictionary<string, Shader>();

            _addressableShaderToStubbedShader.Clear();
            foreach(var kvp in _serializedDictionary)
            {
                var shaderName = kvp.addressableShaderName;
                var shader = kvp.stubbedShader;

                _addressableShaderToStubbedShader.Add(shaderName, shader.shader);
            }
        }

        private void Awake()
        {
            EditorApplication.quitting += EditorApplication_quitting;
        }

        private void EditorApplication_quitting()
        {
            Save(true);
        }

        [InitializeOnLoadMethod]
        private static void CreateDictionaryOnDomainReload()
        {
            var settings = instance;
            if(settings)
            {
                settings.ReloadDictionary();
            }
        }

        [Serializable]
        private struct AddressableShaderToStubbedPair
        {
            public string addressableShaderName;
            public SerializableShaderWrapper stubbedShader;
        }
    }
}