using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.AddressableAssets;

namespace RoR2.Editor.ShaderShit
{
    [CustomEditor(typeof(Material))]
    public class MaterialEditorExtended : MaterialEditor
    {
        [MenuItem("Tools/RoR2EditorKit/Save Assets")]
        public static void SaveAssets()
        {
            AssetDatabase.SaveAssets();
        }
        [MenuItem("Tools/RoR2EditorKit/Domain Reloadd")]
        public static void ForceDomainReload()
        {
            EditorUtility.RequestScriptReload();
        }

        [MenuItem("Tools/RoR2EditorKit/Refresh Asset Database")]
        public static void RefreshDatabase() => AssetDatabase.Refresh();
        public override void OnInspectorGUI()
        {
            if(target is Material mat)
            {
                if(mat.shader.name.StartsWith("Stubbed"))
                {
                    try
                    {
                        var shader = Addressables.LoadAssetAsync<Shader>(mat.shader.name.Substring("Stubbed".Length) + ".shader").WaitForCompletion();

                        if(!MaterialSystemSettings.instance.AlreadyExists(shader.name))
                        {
                            MaterialSystemSettings.instance.Add(shader.name, mat.shader);
                        }

                        SetShader(shader);
                    }
                    catch(Exception e)
                    {
                        Debug.LogError($"Failed to replace the stubbed shader with the real shader  due to an addressables exception, you may need to reimport the catalog.\n {e}");
                    }
                }
            }
            base.OnInspectorGUI();
        }
    }
}