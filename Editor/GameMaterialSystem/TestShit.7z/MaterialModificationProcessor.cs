using UnityEditor;
using UnityEngine;

namespace RoR2.Editor.ShaderShit
{
    public class MaterialModificationProcessor : AssetModificationProcessor
    {
        static string[] OnWillSaveAssets(string[] paths)
        {
            foreach(var asset in paths)
            {
                if(asset.EndsWith(".mat"))
                {
                    var mat = AssetDatabase.LoadAssetAtPath<Material>(asset);
                    if(AssetDatabase.GetAssetPath(mat.shader) == string.Empty)
                    {
                        Debug.Log("Shader assigned to mat does not have a path! assigning stubbed shader.");

                        mat.shader = MaterialSystemSettings.instance.GetStubbed(mat.shader.name);
                    }
                }
            }
            return paths;
        }
    }
}